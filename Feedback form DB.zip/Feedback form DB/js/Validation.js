
var $FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-z0-9.-]+.[A-Z]{2,8}\b$/i;
var $ConNoRegEx = /^([0-9]{10})$/;
var $FeedbackRegEx =/^\b[A-Z0-9._%-]+@[A-z0-9.-]+.[A-Z]{2,8}\b$/i;

$(document).ready(function(){
   /* //first name
    $("#f_name").blur(function(){
        $("#TxtFNameValidation").empty();
        if($(this).val()=="" || $(this).val()==null){
			$("#TxtFNameValidation").html("(*) Name required..!!");
		}
		else{
			if(!$(this).val().match($FNameLNameRegEx)){
				$("#TxtFNameValidation").html("(*) Invalid name..!!");
			}
		}
    });
    $("#f_name").keypress(function(e){
		$("#TxtFNameValidation").empty();
			var Flag=((e.which>=65 && e.which<=90) || (e.which>=97 && e.which<=121));
			if(Flag==false){
				$("#TxtFNameValidation").html("Invalid Input..!!");
			}
		return Flag;
	});

    //Last name
    $("#l_name").blur(function(){
        $("#TxtLNameValidation").empty();
        if($(this).val()=="" || $(this).val()==null){
			$("#TxtLNameValidation").html("(*) Name required..!!");
		}
		else{
			if(!$(this).val().match($FNameLNameRegEx)){
				$("#TxtLNameValidation").html("(*) Invalid name..!!");
			}
		}
    });
    $("#l_name").keypress(function(e){
		$("#TxtLNameValidation").empty();
			var Flag=((e.which>=65 && e.which<=90) || (e.which>=97 && e.which<=121));
			if(Flag==false){
				$("#TxtLNameValidation").html("Invalid Input..!!");
			}
		return Flag;
	});

    //Email id
    $("#email_id").blur(function(){
        $("#TxtEmailIdValidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#TxtEmailIdValidation").html("(*) Email id required..!!");
        }
        else{
            if(!$(this).val().match($EmailIdRegEx)){
                $("#TxtEmailIdValidation").html("(*) Invalid email id..!!");
            }
        }
    });

    //contect number
    $("#c_num").blur(function(){
        $("#TxtConValidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#TxtConValidation").html("(*) Contact no. required..!!");
        }
        else{
            if(!$(this).val().match($ConNoRegEx)){
                $("#TxtConValidation").html("(*) Invalid contact no..!!");
            }
        }
    });
    $("#c_num").keypress(function(e){
        $("#TxtConValidation").empty();
        var Flag=(e.which>=48 && e.which<=57);
        if(Flag==false){
            $("#TxtConValidation").html("Invalid Input..!!");
        }
        return Flag;
    });

    //feedback box
    $("#feed_back").blur(function(){
        $("#TxtFeedbackValidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#TxtFeedbackValidation").html("(*) Feedback required..!!");
        }
        else{
            if(!$(this).val().match($FeedbackRegEx)){
                $("#TxtFeedbackValidation").html("(*) Invalid Feedback..!!");
            }
        }
    });
    $("#feed_back").keypress(function(e){
        $("#TxtFeedbackValidation").empty();
        var Flag=(e.which>=48 && e.which<=57);
        if(Flag==false){
            $("#TxtFeedbackValidation").html("Invalid Input..!!");
        }
        return Flag;
    });
*/
    var TxtFNameFlag=false,TxtFeedbackFlag=false,TxtLNameFlag=false,TxtContactNoFlag=false,TxtEmailIdFlag=false;

	$("#BtnSubmit").click(function(){
		$("#TxtFNameValidation").empty();
		if($("#f_name").val()=="" || $("#f_name").val()==null){
			$("#TxtFNameValidation").html("(*) Name required..!!");
			TxtFNameFlag=false;
		}
		else{
			if(!$("#f_name").val().match($FNameFNameRegEx)){
		        $("#TxtFNameValidation").html("(*) Invalid name..!!");
			    TxtFNameFlag=false;
		    }
		    else{
			    TxtFNameFlag=true;
		    }
		}
        $("#TxtLNameValidation").empty();
		if($("#l_name").val()=="" || $("#l_name").val()==null){
			$("#TxtLNameValidation").html("(*) Name required..!!");
			TxtLNameFlag=false;
		}
		else{
			if(!$("#l_name").val().match($FNameLNameRegEx)){
		        $("#TxtLNameValidation").html("(*) Invalid name..!!");
			    TxtLNameFlag=false;
		    }
		    else{
			    TxtLNameFlag=true;
		    }
		}
		$("#TxtConValidation").empty();
		if($("#c_num").val()=="" || $("#c_num").val()==null){
			$("#TxtConValidation").html("(*) Contact no. required..!!");
				TxtContactNoFlag=false;
		}
		else{
			if(!$("#c_num").val().match($ConNoRegEx)){
				$("#TxtConValidation").html("(*) Invalid contact no..!!");
				TxtContactNoFlag=false;
			}
			else{
				TxtContactNoFlag=true;
			}
		}
		$("#TxtEmailIdValidation").empty();
		if($("#email_id").val()=="" || $("#email_id").val()==null){
			$("#TxtEmailIdValidation").html("(*) Email id required..!!");
			TxtEmailIdFlag=false;
		}
		else{
			if(!$("#email_id").val().match($EmailIdRegEx)){
				$("#TxtEmailIdValidation").html("(*) Invalid email id..!!");
				TxtEmailIdFlag=false;
			}
			else{
				TxtEmailIdFlag=true;
			}
		}
        $("#TxtFeedbackValidation").empty();
		if($("#feed_back").val()=="" || $("#feed_back").val()==null){
			$("#TxtFeedbackValidation").html("(*) Feedback required..!!");
			TxtEmailIdFlag=false;
		}
		else{
			if(!$("#feed_back").val().match($FeedbackRegEx)){
				$("#TxtFeedbackValidation").html("(*) Invalid Feedback..!!");
				TxtFeedbackFlag=false;
			}
			else{
				TxtFeedbackFlag=true;
			}
		}
		if(TxtFNameFlag==true && TxtLNameFlag==true && TxtEmailIdFlag==true     && TxtContactNoFlag==true && TxtFeedbackFlag==true ){
		    $("input,textarea").val("");
			alert("Form submitted successfully..!!");
		}
		else{
			alert("Invalid Input..!!");
		}
	});
})