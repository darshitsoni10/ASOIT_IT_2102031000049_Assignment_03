<?php 

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$emailid= $_POST['emailid'];
$contectno = $_POST['contectno'];
$feedback = $_POST['feedback'];

$con = mysqli_connect("localhost", "root", "", "feedback_form"); //Connection variable

if(mysqli_connect_errno()) 
{
	echo "Failed to connect: " . mysqli_connect_errno();
}
$query = mysqli_query($con, "INSERT INTO `student`(`firstname`, `lastname`, `emailid`, `contectno`, `feedback`) VALUES ('$firstname','$lastname','$emailid','$contectno','$feedback')");
echo '<script>alert("Thank You..! Your Feedback is Valuable to Us"); location.replace(document.referrer);</script>';

?>